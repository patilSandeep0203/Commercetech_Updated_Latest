Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports AjaxControlToolkit.Design

Namespace $rootnamespace$

    Class $baseitemname$Designer 
        Inherits ExtenderControlBaseDesigner(Of $baseitemname$Extender) 

    End Class

End Namespace
