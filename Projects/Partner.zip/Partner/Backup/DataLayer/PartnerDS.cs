﻿namespace DLPartner {


    partial class PartnerDS
    {
        partial class OnlineAppRatesDataTable
        {
        }
    
        partial class ACTOnlineAppSalesOppsDataTable
        {
        }
    
        partial class OptimalCADataTable
        {
        }
    
        partial class CheckServiceBoundsDataTable
        {
        }
    
        partial class CheckServiceBoundsDataTable
        {
        }
    
        partial class MiscReportDataTable
        {
        }
    
        partial class ACTiPayPDFDataTable
        {
        }
    
        partial class SageDataTable
        {
        }
    
        partial class DataTable1DataTable
        {
        }
    
        partial class CheckServicesDataTable
        {
        }
    
        partial class MerchantCashAdvanceDataTable
        {
        }
    
        partial class ResidualsReportsDataTable
        {
        }
    
        partial class ProcessorBoundsDataTable
        {
        }
    
        partial class ACTOnlineAppFieldsDataTable
        {
        }
    
        partial class OnlineAppACTFieldsDataTable
        {
        }
    
        partial class IMS2DataTable
        {
        }

        partial class IPSDataTable
        {
        }
    
        partial class GatewayBoundsDataTable
        {
        }
    
        partial class MerrickDataTable
        {
        }
    
        partial class ACTAuthnetXMLDataTable
        {
        }
    
        partial class ACTSageXMLDataTable
        {
        }
    
        partial class AffiliatesDataTable
        {
        }
    
        partial class ChaseDataTable
        {
        }
    
        partial class ACTiPayXMLDataTable
        {
        }
    
        partial class ACTSagePDFDataTable
        {
        }
    
        partial class ACTChasePDFDataTable
        {
        }
    
        partial class ACTOptimalCAPDFDataTable
        {
        }
    
        partial class ACTOptimalStKittsPDFDataTable
        {
        }
    
        partial class ACTOptimalStKittsPDFDataTable
        {
        }
    }
}
