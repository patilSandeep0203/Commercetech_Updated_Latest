using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using DLPartner;
using DLPartner.PartnerDSTableAdapters;

namespace BusinessLayer
{   
    public class IMSView
    {
        private string ContactID = "";

        //Constructopr
        public IMSView (string ContactID)
        {
            this.ContactID = ContactID;
        }

    
         
    }

}
