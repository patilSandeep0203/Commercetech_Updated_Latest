﻿namespace DLPartner {


    partial class PartnerDS
    {
        partial class ECXLegacyDataTable
        {
        }
    
        partial class RevelDataTable
        {
        }
    
        partial class iPayment3DataTable
        {
        }
    
        partial class OnlineAppRatesDataTable
        {
       }
    
        partial class ACTOnlineAppSalesOppsDataTable
        {
        }
    
        partial class OptimalCADataTable
        {
        }
    
        partial class CheckServiceBoundsDataTable
        {
        }
    
        partial class CheckServiceBoundsDataTable
        {
        }
    
        partial class MiscReportDataTable
        {
        }
    
        partial class ACTiPayPDFDataTable
        {
        }
    
        partial class SageDataTable
        {
        }
    
        partial class DataTable1DataTable
        {
        }
    
        partial class CheckServicesDataTable
        {
        }
    
        partial class MerchantCashAdvanceDataTable
        {
        }
    
        partial class ResidualsReportsDataTable
        {
        }
    
        partial class ProcessorBoundsDataTable
        {
        }
    
        partial class ACTOnlineAppFieldsDataTable
        {
        }
    
        partial class OnlineAppACTFieldsDataTable
        {
        }
    
        partial class IMS2DataTable
        {
        }

        partial class IPSDataTable
        {
        }
    
        partial class GatewayBoundsDataTableMon
        {
        }

        partial class MerrickDataTable
        {
        }
    
        partial class ACTAuthnetXMLDataTable
        {
        }
    
        partial class ACTSageXMLDataTable
        {
        }
    
        partial class AffiliatesDataTable
        {
        }
    
        partial class ChaseDataTable
        {
        }
    
        partial class ACTiPayXMLDataTable
        {
        }
    
        partial class ACTSagePDFDataTable
        {
        }
    
        partial class ACTChasePDFDataTable
        {
        }
    
        partial class ACTOptimalCAPDFDataTable
        {
        }
    
        partial class ACTOptimalStKittsPDFDataTable
        {
        }
    
        partial class ACTOptimalStKittsPDFDataTable
        {
        }
    }
}

namespace DLPartner.PartnerDSTableAdapters {
    partial class CPSTableAdapter
    {
    }

    partial class ECXLegacyTableAdapter
    {
    }

    partial class AffiliatesTableAdapter
    {
    }

    partial class OnlineAppRatesTableAdapter
    {
    }

    partial class OnlineAppSalesOppsTableAdapter
    {
    }

    partial class RevelTableAdapter
    {
    }

    partial class ACTSagePDFTableAdapter
    {
    }

    partial class OnlineAppNotesTableAdapter
    {
    }

    partial class ResidualsReportsTableAdapter
    {
    }

    partial class AuthnetTableAdapter
    {
    }

    partial class ACTOnlineAppFieldsTableAdapter
    {
    }

    partial class OnlineAppACTFieldsTableAdapter
    {
    }

    partial class ProcessorBoundsTableAdapter
    {
    }

    partial class SageTableAdapter
    {
    }

    partial class iPaymentGatewayTableAdapter
    {
    }
    
    
    public partial class OnlineAppSummaryTableAdapter {
    }
}
